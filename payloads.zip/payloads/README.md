# Directory Brute Force Wordlists

This repository contains wordlists for directory brute-forcing, useful for penetration testing, security assessments, and bug bounty hunting.

